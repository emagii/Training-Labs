#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x5358b4ed, "module_layout" },
	{ 0x2b634d09, "ethtool_op_get_link" },
	{ 0xfe5db446, "usbnet_set_msglevel" },
	{ 0xad6e9a82, "usbnet_get_msglevel" },
	{ 0x410037d, "usbnet_tx_timeout" },
	{ 0x5a743f30, "eth_validate_addr" },
	{ 0x574896ba, "usbnet_start_xmit" },
	{ 0x3796c552, "usbnet_stop" },
	{ 0xd74689ea, "usbnet_open" },
	{ 0x7548dbd, "usbnet_disconnect" },
	{ 0xa74583c6, "usbnet_probe" },
	{ 0x15692c87, "param_ops_int" },
	{ 0xcf0b783, "usb_deregister" },
	{ 0xf969cfd6, "usb_register_driver" },
	{ 0xfaf98462, "bitrev32" },
	{ 0x802d0e93, "crc32_le" },
	{ 0x452ab367, "usbnet_write_cmd_async" },
	{ 0x27e1a049, "printk" },
	{ 0x77b93ba5, "usbnet_get_endpoints" },
	{ 0xd6335eb5, "netdev_err" },
	{ 0xeda8a74d, "mii_nway_restart" },
	{ 0xaedb778a, "usbnet_defer_kevent" },
	{ 0x55755d7f, "netif_carrier_on" },
	{ 0x5cf56740, "usbnet_suspend" },
	{ 0x3b40d72e, "usbnet_resume" },
	{ 0x12a38747, "usleep_range" },
	{ 0x874290bc, "netif_carrier_off" },
	{ 0x8a8fb613, "dev_get_drvdata" },
	{ 0xf9a482f9, "msleep" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xbf9b92f1, "mii_check_media" },
	{ 0x3b68e000, "netdev_info" },
	{ 0x7d11c268, "jiffies" },
	{ 0x875eb64e, "usbnet_write_cmd_nopm" },
	{ 0xcb5f3170, "usbnet_write_cmd" },
	{ 0xf2b09e86, "kmem_cache_alloc_trace" },
	{ 0xfe1c648f, "kmalloc_caches" },
	{ 0x69acdf38, "memcpy" },
	{ 0x37a0cba, "kfree" },
	{ 0xd2b09ce5, "__kmalloc" },
	{ 0xd68fe42a, "netdev_warn" },
	{ 0xbe9f659a, "usbnet_read_cmd" },
	{ 0xec4ebce2, "usbnet_read_cmd_nopm" },
	{ 0x991f06ea, "generic_mii_ioctl" },
	{ 0x4e953470, "mii_ethtool_gset" },
	{ 0x439a02f, "mii_ethtool_sset" },
	{ 0x1c7bcffb, "usbnet_get_drvinfo" },
	{ 0xeccf6838, "usbnet_skb_return" },
	{ 0x133346d3, "skb_pull" },
	{ 0xf4dc1c3b, "skb_clone" },
	{ 0x3d8b550b, "skb_trim" },
	{ 0x8af8e24, "__pskb_pull_tail" },
	{ 0xb0e602eb, "memmove" },
	{ 0x26a38852, "dev_kfree_skb_any" },
	{ 0xd913fcf, "skb_copy_expand" },
	{ 0x761bbc0b, "skb_push" },
	{ 0xbdfb6dbb, "__fentry__" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=usbnet";

MODULE_ALIAS("usb:v0B95p1790d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0B95p178Ad*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0DF6p0072d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v17EFp304Bd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0930p0A13d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v04E8pA100d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "C6775D0AD12EE16BAC661AF");
